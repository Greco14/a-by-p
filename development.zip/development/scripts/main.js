Main = {

    init: function(params) {

        navigation = new Navigation();
        navigation.init();

    },
 
};
$(function(){
	Main.init();
});